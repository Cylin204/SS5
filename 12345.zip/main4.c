#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	printf("40/17*13/3 = %d",40/17*13/3);
 printf("\n\n40/17*13/3.0 = %lf",40/17*13/3.0);
 printf("\n\n40/17*13.0/3 = %lf",40/17*13.0/3);
 printf("\n\n40/17.0*13/3 = %lf",40/17.0*13/3);
 return 0;
}
