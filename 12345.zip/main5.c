#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	printf("Result=%d",(4-2*9/6<=3&&(10*2/4-3>3||(1<5&&8>10))));
	return 0;
}
