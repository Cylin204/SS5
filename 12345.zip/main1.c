#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 
{
	float p,n,r;
 p = 1000;
 n = 2.5;
 r = 10.5;
 printf( "\n Amount is : %f", p*n*r/100);
	return 0;
}
